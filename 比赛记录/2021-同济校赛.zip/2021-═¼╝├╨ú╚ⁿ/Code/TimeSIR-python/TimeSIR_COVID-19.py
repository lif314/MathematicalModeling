###### 导入库 #####
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdate
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.model_selection import GridSearchCV

###### 数据分割 ######
def data_spilt(data, orders, start):
    x_train = np.empty((len(data) - start - orders, orders))
    y_train = data[start + orders:]

    for i in range(len(data) - start - orders):
        x_train[i] = data[i + start:start + orders + i]

    return x_train, y_train

######  调用函数实现岭回归 ######
def ridge(x, y):
    print('\nStart searching good parameters for the task...')
    parameters = {'alpha': np.arange(0, 0.100005, 0.000005).tolist(),
                  "tol": [1e-8],
                  'fit_intercept': [True, False],
                  'normalize': [True, False]}

    clf = GridSearchCV(Ridge(), parameters, n_jobs=-1, cv=5)
    clf.fit(x, y)

    print('\nResults for the parameters grid search:')
    print('Model:', clf.best_estimator_)
    print('Score:', clf.best_score_)

    return clf


###### 加载数据 ######
# 数据来源：https://www.covid19india.org/

# 读取数据  —— 多数据集
# 读取全部数据进行处理
# data = pd.read_csv("total_data_all.csv", index_col=["Date_YMD"])
# data = pd.read_csv("daily_data_all.csv", index_col=["Date_YMD"])

# 读取2020年所有数据
# data = pd.read_csv("total_data_2020.csv", index_col=["Date_YMD"])
# data = pd.read_csv("daily_data_2020.csv", index_col=["Date_YMD"])

# 读取2020年分段数据
# data = pd.read_csv("total_data_2020_678.csv", index_col=["Date_YMD"])
# data = pd.read_csv("total_data_2020_789.csv", index_col=["Date_YMD"])
# data = pd.read_csv("total_data_2020_8910.csv", index_col=["Date_YMD"])
# data = pd.read_csv("total_data_2020_91011.csv", index_col=["Date_YMD"])
# data = pd.read_csv("total_data_2020_101112.csv", index_col=["Date_YMD"])
# data = pd.read_csv("total_data_2020_1_121.csv", index_col=["Date_YMD"])

# 读取2021/01/01-2021/04/28所有数据
data = pd.read_csv("total_data_2021.csv", index_col=["Date_YMD"])
# data = pd.read_csv("daily_data_2021.csv", index_col=["Date_YMD"])

# 读取2021年1/2月数据预测3月数据
# data = pd.read_csv("total_data_2021_12.csv", index_col=["Date_YMD"])
# data = pd.read_csv("daily_data_2021_12.csv", index_col=["Date_YMD"])

# 读取2021年2/3月数据预测4月数据
# data = pd.read_csv("total_data_2021_23.csv", index_col=["Date_YMD"])
# data = pd.read_csv("daily_data_2021_23.csv", index_col=["Date_YMD"])

# 读取2021年3/4月数据预测5月数据
# data = pd.read_csv("total_data_2021_34.csv", index_col=["Date_YMD"])
# data = pd.read_csv("daily_data_2021_34.csv", index_col=["Date_YMD"])


# I_cml = cumulative confirmed cases —— 累计确诊病例
I_cml = np.array(data["Total_Confirmed"], dtype=np.float64)[:-27]

# recovered = cumulative recovered cases —— 累积康复病例
recovered = np.array(data["Total_Recovered"], dtype=np.float64)[:-27]

# death = cumulative deaths —— 累积死亡人数
death = np.array(data["Total_Deceased"], dtype=np.float64)[:-27]


population = 1391160677  # 印度目前人口，数据来源：https://www.worldometers.info/world-population/india-population/


########## 数据预处理 ##########
# I: 当前确诊人数 = 累积确诊人数 - 累积康复人数 - 死亡人数
I = I_cml - recovered - death

# R：移除人群 = 康复人数 + 死亡人数
R = recovered + death

n = np.array([population] * len(I), dtype=np.float64)

S = n - I - R

I_diff = np.array([I[:-1], I[1:]], dtype=np.float64).T
R_diff = np.array([R[:-1], R[1:]], dtype=np.float64).T

# gamma: 移除率
gamma = (R[1:] - R[:-1]) / I[:-1]
# beta: 有效接触率
beta = n[:-1] * (I[1:] - I[:-1] + R[1:] - R[:-1]) / (I[:-1] * (n[:-1] - I[:-1] - R[:-1]))
# R0：基本再生数-平均多少个健康者被感染者传播
R0 = beta / gamma


###### 岭回归参数 ######
##### 两个FIR滤波器 #####
orders_beta = 3
orders_gamma = 3

##### S在ridge回归中选择数据训练的开始日期 #####
start_beta = 10
start_gamma = 10


########## Print Info ##########
print("\n The latest transmission rate beta of SIR model:", beta[-1])
print("The latest recovering rate gamma of SIR model:", gamma[-1])
print("The latest basic reproduction number R0:", R0[-1])


########## 岭回归 ##########
##### 将数据拆分为训练集和测试集 #####
x_beta, y_beta = data_spilt(beta, orders_beta, start_beta)
x_gamma, y_gamma = data_spilt(gamma, orders_gamma, start_gamma)

##### 岭回归计算良好参数 #####
clf_beta = ridge(x_beta, y_beta)
clf_gamma = ridge(x_gamma, y_gamma)

##### 设置参数，减少运行时间 #####
# clf_beta = Ridge(alpha=0.003765, copy_X=True, fit_intercept=False, max_iter=None, normalize=True, random_state=None, solver='auto', tol=1e-08).fit(x_beta, y_beta)
# clf_gamma = Ridge(alpha=0.001675, copy_X=True, fit_intercept=False, max_iter=None,normalize=True, random_state=None, solver='auto', tol=1e-08).fit(x_gamma, y_gamma)

beta_hat = clf_beta.predict(x_beta)
gamma_hat = clf_gamma.predict(x_gamma)


###### 拟合优度R^2的计算 #######
def sst(y_no_fitting):
    """
    计算SST(total sum of squares) 总平方和
    :param y_no_predicted: List[int] or array[int] 待拟合的y
    :return: 总平方和SST
    """
    y_mean = sum(y_no_fitting) / len(y_no_fitting)
    s_list =[(y - y_mean)**2 for y in y_no_fitting]
    sst = sum(s_list)
    return sst

def ssr(y_fitting, y_no_fitting):
    """
    计算SSR(regression sum of squares) 回归平方和
    :param y_fitting: List[int] or array[int]  拟合好的y值
    :param y_no_fitting: List[int] or array[int] 待拟合y值
    :return: 回归平方和SSR
    """
    y_mean = sum(y_no_fitting) / len(y_no_fitting)
    s_list =[(y - y_mean)**2 for y in y_fitting]
    ssr = sum(s_list)
    return ssr


def sse(y_fitting, y_no_fitting):
    """
    计算SSE(error sum of squares) 残差平方和
    :param y_fitting: List[int] or array[int] 拟合好的y值
    :param y_no_fitting: List[int] or array[int] 待拟合y值
    :return: 残差平方和SSE
    """
    s_list = [(y_fitting[i] - y_no_fitting[i])**2 for i in range(len(y_fitting))]
    sse = sum(s_list)
    return sse

def goodness_of_fit(y_fitting, y_no_fitting):
    """
    计算拟合优度R^2
    :param y_fitting: List[int] or array[int] 拟合好的y值
    :param y_no_fitting: List[int] or array[int] 待拟合y值
    :return: 拟合优度R^2
    """
    SSR = ssr(y_fitting, y_no_fitting)
    SST = sst(y_no_fitting)
    rr = SSR / SST
    return rr
#### 打印拟合测试结果 #####
print("\nbeta_R^2: ", goodness_of_fit(beta_hat,beta))
print("\ngamma_R^2: ", goodness_of_fit(gamma_hat,gamma))

##### 绘制传播速率和恢复速率拟合结果 #####
plt.figure(1)
plt.plot(y_beta, label=r'$\beta (t)$')
plt.plot(beta_hat, label=r'$\hat{\beta}(t)$')
plt.xlabel('day')
plt.title('transmission rate')
plt.legend()

plt.figure(2)
plt.plot(y_gamma, label=r'$\gamma (t)$')
plt.plot(gamma_hat, label=r'$\hat{\gamma}(t)$')
plt.xlabel('day')
plt.title(' recovering rate')
plt.legend()

plt.figure(3)
plt.plot(R0, label=r'$R_0$')
# plt.plot(gamma_hat, label=r'$\hat{\gamma}(t)$')
plt.xlabel('day')
plt.title('$R_0$')
plt.legend()

########## TimeSIR模型 ##########

##### TimeSIR模型参数计算 #####
stop_X = 0 # 停止标志
# stop_day = 100 # 最大迭代天数 —— 预测天数 all_data
stop_day = 100 # 最大迭代天数 —— 预测天数 month_data

# 类型I和类型II感染者概率，其中beta/beta1/beta2/gamma是阶段性常数
# w1 = (I[i+1]/I[i] - beta2 + gamma - 1) / (beta1 - beta2)
# w2 = 1 - w1

day_count = 0
turning_point = 0

S_predict = [S[-1]]
I_predict = [I[-1]]
R_predict = [R[-1]]

###### 预测值计算 ######
predict_beta = np.array(beta[-orders_beta:]).tolist()
predict_gamma = np.array(gamma[-orders_gamma:]).tolist()
while (I_predict[-1] >= stop_X) and (day_count <= stop_day):
    if predict_beta[-1] > predict_gamma[-1]:
        turning_point += 1

    next_beta = clf_beta.predict(np.asarray([predict_beta[-orders_beta:]]))[0]
    next_gamma = clf_gamma.predict(np.asarray([predict_gamma[-orders_gamma:]]))[0]

    if next_beta < 0:
        next_beta = 0
    if next_gamma < 0:
        next_gamma = 0

    predict_beta.append(next_beta)
    predict_gamma.append(next_gamma)

    next_S = ((-predict_beta[-1] * S_predict[-1] *
               I_predict[-1]) / n[-1]) + S_predict[-1]
    next_X = ((predict_beta[-1] * S_predict[-1] * I_predict[-1]) /
              n[-1]) - (predict_gamma[-1] * I_predict[-1]) + I_predict[-1]
    next_R = (predict_gamma[-1] * I_predict[-1]) + R_predict[-1]

    S_predict.append(next_S)
    I_predict.append(next_X)
    R_predict.append(next_R)

    day_count += 1

###### 数据结果可视化 ######
# 打印信息
print('\n明日确证人数:', np.rint(I_predict[1] + R_predict[1]))
print('明日感染人数:', np.rint(I_predict[1]))
print('明日移除人数:', np.rint(R_predict[1]))

print('\n终止天数:', day_count)
print('终止天确证病例:', np.rint(I_predict[-2] + R_predict[-2]))

print('\n转折点:', turning_point)



# 绘制TimeSIR模型预测结果
# print("I\_predict", I_predict)
# print("R\_predict", R_predict)

plt.figure(4)
plt.plot(range(len(I) - 1, len(I) - 1 + len(I_predict)), I_predict, '.', label=r'$\hat{I}(t)\_predict$', color='darkorange')
plt.plot(range(len(I) - 1, len(I) - 1 + len(I_predict)), R_predict, '.', label=r'$\hat{R}(t)\_predict$', color='limegreen')
plt.plot(range(len(I)), I, '-', label=r'$I(t)$', color='chocolate')
plt.plot(range(len(I)), R, '-', label=r'$R(t)$', color='darkgreen')
plt.xlabel('Day')
plt.ylabel('Person')
plt.title('TimeSIR model result')
plt.legend()
