clear;clc;
data=csvread('Bdata.csv');
A=data(:,1)';
school_number=data(:,2)';

zuzhang_number=fix(sum(school_number)*2/(11+2/3));
zuzhang=3;

teacher=data(1:12,3)';
D=3*school_number;
n=length(teacher);
[e,r]=sort(D,'descend');
c1=school_number(r);
c1B=zeros([30,12]);
A1=A(r);
p=1;
for i=1:length(A)%ѧУ��
    s=0; %��ָ������
    while s<e(i)%��3����
      j=p;%��ί
      c1B(i,j)=1;
      s=s+1;
      p=p+1;
        if A1(i)==teacher(j)%��ѡ��У
           c1B(i,j)=0;
           s=s-1;
        end
        if j==n
            p=1;%ѭ��ѡ���ѭ���̳�λ��
        end
    end
end
c1B;
[a,b]=sort(r);
C1B=c1B(b,:);
C1B;  %����ί�Ƿ����ĸ�У�Ծ�����Ϊ1������Ϊ0��
g=sum(C1B);
h=sum(C1B,2);
f=fix(sum(D)/n);%��ί���ĵ������Ծ���
v=0;
for j=1:n
    for i=1:length(A)
        if C1B(i,j)~=0
            v=v+school_number(i);
        end
    end
v;
    for i=1:length(A)
        if C1B(i,j)~=0
            if (f*school_number(i)/v)<0.5
                sp(i,j)=1;
            else
            sp(i,j)=round(f*school_number(i)/v);
            end
        end
    end
    v=0;
end
x=D'-sum(sp,2);
y=sum(sp);
[e1,r1]=sort(y,'descend');%��ί��������ʱ
temp=zeros([1,n]);
for i=1:length(A)
        while x(i)<0
            for i1=1:n
                if(temp(i1)>0&&sp(i,r1(i1))~=0)
                    sp(i,r1(i1))=sp(i,r1(i1))-1;
                    temp(i1)=temp(i1)-1;
                    break;
                end
                if(i1==n)
                    for ii1=1:n
                        if(sp(i,r1(ii1))~=0)
                        sp(i,r1(ii1))=sp(i,r1(ii1))-1;
                        temp(ii1)=temp(ii1)-1;
                        break;
                        end
                    end
                end
            end
        x=D'-sum(sp,2);
        y=sum(sp);
        [e1,r1]=sort(y,'descend');
        end
        [e1,r1]=sort(y);
       
end
for i=1:length(A)
     [e1,r1]=sort(y);
    while x(i)>0
           for i2=1:n
                if(temp(i2)<0&&sp(i,r1(i2))~=0)
                    sp(i,r1(i2))=sp(i,r1(i2))+1;
                    temp(i2)=temp(i2)+1;
                    break;
                end
                if(i2==n)
                    for ii2=1:n
                        if(sp(i,r1(ii2))~=0)
                        sp(i,r1(ii2))=sp(i,r1(ii2))+1;
                        temp(ii2)=temp(ii2)+1;
                        break;
                        end
                    end
                end
            end
        x=D'-sum(sp,2);
        y=sum(sp);
        [e1,r1]=sort(y);
        end
end
sp%��ίӦ���ĸ�У�ļ����Ծ�
sp_sum=sum(sp,1);
juan=zeros([1,30]);
for i=1:(sp_sum(3)-zuzhang_number)
    [max_sp,index]=max(sp,[],1);
    temp=index(3);
    sp(temp,3)=sp(temp,3)-1;
    juan(temp)=juan(temp)+1;
end
sp_sum=sum(sp,1);
Q=zeros([1,12]);
for i=1:30 %ѧУѭ��
    while juan(i)>0
        for ii=1:12
            if(ii==3)
                Q(ii)=2*2/sp_sum(ii);
            else
                Q(ii)=3*3/sp_sum(ii);
            end
        end
        [~,rr]=sort(Q,'descend');
        if teacher(rr(1))~=i
            sp_sum(rr(1))=sp_sum(rr(1))+1;
            sp(i,rr(1))=sp(i,rr(1))+1;
        else 
            sp_sum(rr(2))=sp_sum(rr(2))+1;
            sp(i,rr(2))=sp(i,rr(2))+1;
        end
        juan(i)=juan(i)-1;
    end
end

K=0;
for i=1:length(A)
    k=1;
    K=K+school_number(i);
    for j=1:n
        while sp(i,j)>0
            if i>1
                M1(K-school_number(i)+k,j)=1;
            else
                M1(k,j)=1; 
            end
            sp(i,j)=sp(i,j)-1;
            k=k+1;
            if k>school_number(i)
                k=1;
            end
        end
    end
end
M1;  %���Ծ���ţ�����ί�Ƿ����ĸ��Ծ���
xlswrite('B.xlsx',M1);
sum(M1,1)
sum(M1,2);
sum(sum(M1))/3
